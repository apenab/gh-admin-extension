console.log("This is background script");
//# sourceMappingURL=background.js.map